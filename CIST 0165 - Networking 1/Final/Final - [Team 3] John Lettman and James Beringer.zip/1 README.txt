############################
## Networking 1 Final Lab ##
############################

Team number         |
---------------------

3


Project members     |
---------------------

* John Lettman
* James Beringer



Network allocations |
---------------------

LAN 192.168.128.0/18
145 HOSTS -- 192.168.139.0/24   VLAN 8
51  HOSTS -- 192.168.141.0/25   VLAN 11
193 HOSTS -- 192.168.137.0/24   VLAN 6
510 HOSTS -- 192.168.128.0/22   VLAN 1
177 HOSTS -- 192.168.38.0/24    VLAN 7
88  HOSTS -- 192.168.140.0/25   VLAN 9
213 HOSTS -- 192.168.134.0/24   VLAN 3
199 HOSTS -- 192.168.136.0/24   VLAN 5
76  HOSTS -- 192.168.140.128/25 VLAN 10
201 HOSTS -- 192.168.135.0/24   VLAN 4
289 HOSTS -- 192.168.132.0/32   VLAN 2

MANAGE LANS 192.168.143.0/24-192.168.50.0/24

WAN 211.78.0.0/24
INET - BRADFORD........ 211.78.0.26 - 211.78.0.25
BRADFORD - OLEAN....... 211.78.0.1 - 211.78.0.2
OLEAN - BRAZIL......... 211.78.0.13 - 211.78.0.14
BRADFORD - PITTSBURGH.. 211.78.0.5 - 211.78.0.6
BRADFORD - LONDON...... 211.78.0.9 - 211.78.0.10
LONDON - PARIS......... 211.78.0.17 - 211.78.0.18
PARIS - LeHAVRE........ 211.78.0.21 - 211.78.0.22 